--
-- PostgreSQL database dump
--

\restrict OYdQgb1vMkVlYMG5WUEt5293zheBaZIGXBVON2bRMr7fyqaWbuddj2RDt367oKa

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: changelog_action; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.changelog_action AS ENUM (
    'created',
    'status_changed',
    'items_modified',
    'priority_changed',
    'assigned',
    'shipping_updated',
    'note_added',
    'partial_fulfillment_approved',
    'quality_issue_reported',
    'cancelled',
    'restored'
);


--
-- Name: inventory_change_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.inventory_change_type AS ENUM (
    'manual_adjustment',
    'order_shipped',
    'order_cancelled',
    'return_received',
    'stock_received',
    'damaged',
    'cycle_count',
    'reservation',
    'reservation_released'
);


--
-- Name: order_priority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.order_priority AS ENUM (
    'low',
    'normal',
    'high',
    'urgent'
);


--
-- Name: order_quality_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.order_quality_type AS ENUM (
    'wrong_item',
    'wrong_quantity',
    'damaged',
    'missing_item',
    'labeling_error',
    'packaging_error',
    'other'
);


--
-- Name: order_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.order_status AS ENUM (
    'pending',
    'confirmed',
    'processing',
    'picking',
    'picked',
    'partially_shipped',
    'shipped',
    'delivered',
    'cancelled',
    'on_hold'
);


--
-- Name: shipping_company; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.shipping_company AS ENUM (
    'brt',
    'dhl',
    'gls',
    'sda',
    'tnt',
    'ups',
    'fedex',
    'poste_italiane',
    'other',
    'pickup'
);


--
-- Name: user_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.user_role AS ENUM (
    'admin',
    'front_office',
    'warehouse'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: barcode_scan_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.barcode_scan_logs (
    id integer NOT NULL,
    barcode character varying(100) NOT NULL,
    scan_type character varying(50),
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    user_id integer,
    product_id integer,
    notes text,
    quantity integer
);


--
-- Name: barcode_scan_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.barcode_scan_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: barcode_scan_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.barcode_scan_logs_id_seq OWNED BY public.barcode_scan_logs.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    color character varying(7),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    vat_number character varying(50),
    address text,
    city character varying(100),
    state character varying(100),
    postal_code character varying(20),
    country character varying(100) DEFAULT 'IT'::character varying,
    email character varying(255),
    phone character varying(50),
    contact_person character varying(255),
    shipping_company public.shipping_company,
    preferred_shipping_company public.shipping_company,
    billing_company character varying(255),
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: inventory_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_changes (
    id integer NOT NULL,
    product_id integer NOT NULL,
    user_id integer,
    change_type public.inventory_change_type NOT NULL,
    previous_quantity integer NOT NULL,
    new_quantity integer NOT NULL,
    quantity_changed integer NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    reference character varying(255),
    notes text
);


--
-- Name: inventory_changes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_changes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_changes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_changes_id_seq OWNED BY public.inventory_changes.id;


--
-- Name: order_changelogs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_changelogs (
    id integer NOT NULL,
    order_id integer NOT NULL,
    user_id integer,
    action public.changelog_action NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    changes jsonb,
    previous_values jsonb,
    notes text
);


--
-- Name: order_changelogs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_changelogs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_changelogs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_changelogs_id_seq OWNED BY public.order_changelogs.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    order_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    shipped_quantity integer DEFAULT 0 NOT NULL,
    shipping_status character varying(50),
    has_quality_issues boolean DEFAULT false NOT NULL,
    picked boolean DEFAULT false NOT NULL,
    actual_quantity integer,
    picked_at timestamp with time zone,
    picked_by_id integer,
    CONSTRAINT chk_quantity_positive CHECK ((quantity > 0)),
    CONSTRAINT chk_shipped_quantity_non_negative CHECK ((shipped_quantity >= 0))
);


--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: order_quality; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_quality (
    id integer NOT NULL,
    order_id integer NOT NULL,
    order_number character varying(50),
    report_date timestamp with time zone DEFAULT now() NOT NULL,
    reported_by_id integer,
    error_type public.order_quality_type NOT NULL,
    description text,
    affected_product_ids jsonb,
    corrective_action text,
    inventory_adjusted boolean DEFAULT false NOT NULL,
    resolved boolean DEFAULT false NOT NULL,
    resolved_by_id integer,
    resolved_date timestamp with time zone,
    root_cause text,
    preventive_measures text
);


--
-- Name: order_quality_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_quality_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_quality_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_quality_id_seq OWNED BY public.order_quality.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    order_number character varying(50) NOT NULL,
    customer_id integer NOT NULL,
    order_date timestamp with time zone DEFAULT now() NOT NULL,
    estimated_shipping_date timestamp with time zone,
    actual_shipping_date timestamp with time zone,
    status public.order_status DEFAULT 'pending'::public.order_status NOT NULL,
    priority public.order_priority DEFAULT 'normal'::public.order_priority NOT NULL,
    area character varying(100),
    notes text,
    has_shipping_document boolean DEFAULT false NOT NULL,
    is_partial_fulfillment boolean DEFAULT false NOT NULL,
    partial_fulfillment_approved boolean DEFAULT false NOT NULL,
    partial_fulfillment_approved_by_id integer,
    partial_fulfillment_approved_at timestamp with time zone,
    percentage_shipped real DEFAULT 0,
    created_by_id integer,
    updated_by_id integer,
    last_updated timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: product_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_tags (
    product_id integer NOT NULL,
    tag_id integer NOT NULL
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    sku character varying(50) NOT NULL,
    barcode character varying(100),
    category_id integer,
    description text,
    min_stock_level integer DEFAULT 0 NOT NULL,
    current_stock integer DEFAULT 0 NOT NULL,
    reserved_stock integer DEFAULT 0 NOT NULL,
    location character varying(100),
    units_per_box integer,
    image_path text,
    last_stock_update timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_current_stock_non_negative CHECK ((current_stock >= 0)),
    CONSTRAINT chk_reserved_lte_current CHECK ((reserved_stock <= current_stock)),
    CONSTRAINT chk_reserved_stock_non_negative CHECK ((reserved_stock >= 0))
);


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    user_id integer NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: shipping_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipping_documents (
    id integer NOT NULL,
    order_id integer NOT NULL,
    document_path text NOT NULL,
    document_type character varying(50),
    tracking_number character varying(100),
    upload_date timestamp with time zone DEFAULT now() NOT NULL,
    notes text
);


--
-- Name: shipping_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shipping_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shipping_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shipping_documents_id_seq OWNED BY public.shipping_documents.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    color character varying(7),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: unshipped_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unshipped_items (
    id integer NOT NULL,
    order_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    customer_id integer,
    original_order_number character varying(50),
    date timestamp with time zone DEFAULT now() NOT NULL,
    shipped boolean DEFAULT false NOT NULL,
    shipped_in_order_id integer,
    shipped_at timestamp with time zone,
    authorized boolean DEFAULT false NOT NULL,
    authorized_by_id integer,
    authorized_at timestamp with time zone,
    notes text
);


--
-- Name: unshipped_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.unshipped_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: unshipped_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.unshipped_items_id_seq OWNED BY public.unshipped_items.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password text NOT NULL,
    full_name character varying(100) NOT NULL,
    role public.user_role DEFAULT 'warehouse'::public.user_role NOT NULL,
    email character varying(255),
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_login timestamp with time zone
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: barcode_scan_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcode_scan_logs ALTER COLUMN id SET DEFAULT nextval('public.barcode_scan_logs_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: inventory_changes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_changes ALTER COLUMN id SET DEFAULT nextval('public.inventory_changes_id_seq'::regclass);


--
-- Name: order_changelogs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_changelogs ALTER COLUMN id SET DEFAULT nextval('public.order_changelogs_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: order_quality id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_quality ALTER COLUMN id SET DEFAULT nextval('public.order_quality_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: shipping_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_documents ALTER COLUMN id SET DEFAULT nextval('public.shipping_documents_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: unshipped_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unshipped_items ALTER COLUMN id SET DEFAULT nextval('public.unshipped_items_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: barcode_scan_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.barcode_scan_logs (id, barcode, scan_type, "timestamp", user_id, product_id, notes, quantity) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, description, color, created_at) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, name, vat_number, address, city, state, postal_code, country, email, phone, contact_person, shipping_company, preferred_shipping_company, billing_company, notes, created_at) FROM stdin;
\.


--
-- Data for Name: inventory_changes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_changes (id, product_id, user_id, change_type, previous_quantity, new_quantity, quantity_changed, "timestamp", reference, notes) FROM stdin;
\.


--
-- Data for Name: order_changelogs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_changelogs (id, order_id, user_id, action, "timestamp", changes, previous_values, notes) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, order_id, product_id, quantity, shipped_quantity, shipping_status, has_quality_issues, picked, actual_quantity, picked_at, picked_by_id) FROM stdin;
\.


--
-- Data for Name: order_quality; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_quality (id, order_id, order_number, report_date, reported_by_id, error_type, description, affected_product_ids, corrective_action, inventory_adjusted, resolved, resolved_by_id, resolved_date, root_cause, preventive_measures) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, order_number, customer_id, order_date, estimated_shipping_date, actual_shipping_date, status, priority, area, notes, has_shipping_document, is_partial_fulfillment, partial_fulfillment_approved, partial_fulfillment_approved_by_id, partial_fulfillment_approved_at, percentage_shipped, created_by_id, updated_by_id, last_updated, created_at) FROM stdin;
\.


--
-- Data for Name: product_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_tags (product_id, tag_id) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, sku, barcode, category_id, description, min_stock_level, current_stock, reserved_stock, location, units_per_box, image_path, last_stock_update, created_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, user_id, expires_at) FROM stdin;
xfy4fjejq2c56ig3bigyah7246ugkzadr54ocqha	1	2026-04-18 15:56:01.866+00
\.


--
-- Data for Name: shipping_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipping_documents (id, order_id, document_path, document_type, tracking_number, upload_date, notes) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tags (id, name, description, color, created_at) FROM stdin;
\.


--
-- Data for Name: unshipped_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unshipped_items (id, order_id, product_id, quantity, customer_id, original_order_number, date, shipped, shipped_in_order_id, shipped_at, authorized, authorized_by_id, authorized_at, notes) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, password, full_name, role, email, active, created_at, last_login) FROM stdin;
1	admin	$2b$12$0KTMLRP/.SmVuxVMBibJbusG8l9RdkCFT/6/A6/TUwsFuELTLdLEa	System Administrator	admin	\N	t	2026-03-19 14:27:40.539756+00	2026-03-19 15:56:01.916+00
\.


--
-- Name: barcode_scan_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.barcode_scan_logs_id_seq', 1, false);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_id_seq', 1, false);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customers_id_seq', 1, false);


--
-- Name: inventory_changes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventory_changes_id_seq', 1, false);


--
-- Name: order_changelogs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_changelogs_id_seq', 1, false);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_items_id_seq', 1, false);


--
-- Name: order_quality_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_quality_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 1, false);


--
-- Name: shipping_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shipping_documents_id_seq', 1, false);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tags_id_seq', 1, false);


--
-- Name: unshipped_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.unshipped_items_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: barcode_scan_logs barcode_scan_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcode_scan_logs
    ADD CONSTRAINT barcode_scan_logs_pkey PRIMARY KEY (id);


--
-- Name: categories categories_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_name_unique UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: inventory_changes inventory_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_changes
    ADD CONSTRAINT inventory_changes_pkey PRIMARY KEY (id);


--
-- Name: order_changelogs order_changelogs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_changelogs
    ADD CONSTRAINT order_changelogs_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: order_quality order_quality_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_quality
    ADD CONSTRAINT order_quality_pkey PRIMARY KEY (id);


--
-- Name: orders orders_order_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_number_unique UNIQUE (order_number);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: product_tags product_tags_product_id_tag_id_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_tags
    ADD CONSTRAINT product_tags_product_id_tag_id_pk PRIMARY KEY (product_id, tag_id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_sku_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_sku_unique UNIQUE (sku);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: shipping_documents shipping_documents_order_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_documents
    ADD CONSTRAINT shipping_documents_order_id_unique UNIQUE (order_id);


--
-- Name: shipping_documents shipping_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_documents
    ADD CONSTRAINT shipping_documents_pkey PRIMARY KEY (id);


--
-- Name: tags tags_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_name_unique UNIQUE (name);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: unshipped_items unshipped_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unshipped_items
    ADD CONSTRAINT unshipped_items_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: idx_inventory_changes_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inventory_changes_product_id ON public.inventory_changes USING btree (product_id);


--
-- Name: idx_inventory_changes_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inventory_changes_timestamp ON public.inventory_changes USING btree ("timestamp");


--
-- Name: idx_order_items_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_items_order_id ON public.order_items USING btree (order_id);


--
-- Name: idx_order_items_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_items_product_id ON public.order_items USING btree (product_id);


--
-- Name: idx_orders_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_customer_id ON public.orders USING btree (customer_id);


--
-- Name: idx_orders_order_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_orders_order_number ON public.orders USING btree (order_number);


--
-- Name: idx_orders_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_status ON public.orders USING btree (status);


--
-- Name: idx_products_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_barcode ON public.products USING btree (barcode);


--
-- Name: idx_products_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_category_id ON public.products USING btree (category_id);


--
-- Name: idx_products_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_sku ON public.products USING btree (sku);


--
-- Name: barcode_scan_logs barcode_scan_logs_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcode_scan_logs
    ADD CONSTRAINT barcode_scan_logs_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: barcode_scan_logs barcode_scan_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcode_scan_logs
    ADD CONSTRAINT barcode_scan_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: inventory_changes inventory_changes_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_changes
    ADD CONSTRAINT inventory_changes_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: inventory_changes inventory_changes_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_changes
    ADD CONSTRAINT inventory_changes_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: order_changelogs order_changelogs_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_changelogs
    ADD CONSTRAINT order_changelogs_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_changelogs order_changelogs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_changelogs
    ADD CONSTRAINT order_changelogs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: order_items order_items_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_picked_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_picked_by_id_users_id_fk FOREIGN KEY (picked_by_id) REFERENCES public.users(id);


--
-- Name: order_items order_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: order_quality order_quality_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_quality
    ADD CONSTRAINT order_quality_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: order_quality order_quality_reported_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_quality
    ADD CONSTRAINT order_quality_reported_by_id_users_id_fk FOREIGN KEY (reported_by_id) REFERENCES public.users(id);


--
-- Name: order_quality order_quality_resolved_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_quality
    ADD CONSTRAINT order_quality_resolved_by_id_users_id_fk FOREIGN KEY (resolved_by_id) REFERENCES public.users(id);


--
-- Name: orders orders_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: orders orders_customer_id_customers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_customers_id_fk FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: orders orders_partial_fulfillment_approved_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_partial_fulfillment_approved_by_id_users_id_fk FOREIGN KEY (partial_fulfillment_approved_by_id) REFERENCES public.users(id);


--
-- Name: orders orders_updated_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_updated_by_id_users_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.users(id);


--
-- Name: product_tags product_tags_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_tags
    ADD CONSTRAINT product_tags_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_tags product_tags_tag_id_tags_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_tags
    ADD CONSTRAINT product_tags_tag_id_tags_id_fk FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: products products_category_id_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: sessions sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: shipping_documents shipping_documents_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_documents
    ADD CONSTRAINT shipping_documents_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: unshipped_items unshipped_items_authorized_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unshipped_items
    ADD CONSTRAINT unshipped_items_authorized_by_id_users_id_fk FOREIGN KEY (authorized_by_id) REFERENCES public.users(id);


--
-- Name: unshipped_items unshipped_items_customer_id_customers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unshipped_items
    ADD CONSTRAINT unshipped_items_customer_id_customers_id_fk FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: unshipped_items unshipped_items_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unshipped_items
    ADD CONSTRAINT unshipped_items_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: unshipped_items unshipped_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unshipped_items
    ADD CONSTRAINT unshipped_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: unshipped_items unshipped_items_shipped_in_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unshipped_items
    ADD CONSTRAINT unshipped_items_shipped_in_order_id_orders_id_fk FOREIGN KEY (shipped_in_order_id) REFERENCES public.orders(id);


--
-- PostgreSQL database dump complete
--

\unrestrict OYdQgb1vMkVlYMG5WUEt5293zheBaZIGXBVON2bRMr7fyqaWbuddj2RDt367oKa

